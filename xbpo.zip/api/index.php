<?php
/**
 * XBPO Communications - Full PHP API Router for Plesk Shared Hosting (IIS / Apache + MariaDB)
 * Replaces server.js when running on PHP hosting without Node.js.
 */

require_once __DIR__ . '/bootstrap.php';

xbpo_security_headers();

$method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
$route = '';
if (isset($_GET['route'])) {
    $route = trim((string)$_GET['route'], '/');
} else {
    $uriPath = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '';
    $pos = strpos($uriPath, '/api/');
    if ($pos !== false) {
        $route = trim(substr($uriPath, $pos + 5), '/');
    }
}

function xbpo_body(): array
{
    static $cached = null;
    if ($cached !== null) {
        return $cached;
    }
    $raw = file_get_contents('php://input');
    if (!$raw) {
        $cached = [];
        return $cached;
    }
    if (strlen($raw) > 6 * 1024 * 1024) {
        xbpo_json(413, ['error' => 'Payload too large.']);
    }
    $decoded = json_decode($raw, true);
    $cached = is_array($decoded) ? $decoded : [];
    return $cached;
}

function xbpo_require_admin(): array
{
    $user = xbpo_current_admin();
    if (!$user) {
        xbpo_json(401, ['error' => 'Authentication required.']);
    }
    return $user;
}

function xbpo_require_master(array $user): void
{
    if (($user['role'] ?? '') !== 'master' && strtolower((string)($user['email'] ?? '')) !== XBPO_MASTER_EMAIL) {
        xbpo_json(403, ['error' => 'Master administrator privileges required.']);
    }
}

function xbpo_require_editor(array $user): void
{
    if (!in_array($user['role'] ?? '', ['master', 'admin'], true)) {
        xbpo_json(403, ['error' => 'Administrator privileges required to modify records or settings.']);
    }
}

function xbpo_get_settings(PDO $pdo): array
{
    $stmt = $pdo->prepare('SELECT * FROM site_settings WHERE setting_key = ? LIMIT 1');
    $stmt->execute(['public']);
    $r = $stmt->fetch();
    if (!$r) {
        return array_merge(XBPO_DEFAULT_SETTINGS, ['updatedBy' => 'system', 'updatedAt' => xbpo_iso_date(date('Y-m-d H:i:s'))]);
    }
    $spId = (string)($r['spreadsheet_id'] ?? '');
    $drId = (string)($r['drive_folder_id'] ?? '');
    return [
        'instagramUrl' => $r['instagram_url'],
        'facebookUrl' => $r['facebook_url'],
        'googleUrl' => $r['google_url'],
        'contactEmail' => $r['contact_email'],
        'contactPhone' => $r['contact_phone'],
        'appsScriptUrl' => $r['apps_script_url'] ?? '',
        'spreadsheetId' => $spId,
        'driveFolderId' => $drId,
        'spreadsheetUrl' => $spId !== '' ? "https://docs.google.com/spreadsheets/d/{$spId}/edit" : '',
        'driveFolderUrl' => $drId !== '' ? "https://drive.google.com/drive/folders/{$drId}" : '',
        'updatedBy' => $r['updated_by'],
        'updatedAt' => xbpo_iso_date($r['updated_at']),
    ];
}

function xbpo_list_roles(PDO $pdo, bool $activeOnly = false): array
{
    $sql = $activeOnly
        ? 'SELECT * FROM career_roles WHERE active = 1 ORDER BY sort_order ASC, name ASC'
        : 'SELECT * FROM career_roles ORDER BY sort_order ASC, name ASC';
    $rows = $pdo->query($sql)->fetchAll();
    return array_map(static function ($r) {
        return [
            'id' => $r['id'],
            'name' => $r['name'],
            'description' => $r['description'] ?? '',
            'active' => (bool)$r['active'],
            'sortOrder' => (int)($r['sort_order'] ?? 0),
            'createdAt' => xbpo_iso_date($r['created_at']),
            'updatedAt' => xbpo_iso_date($r['updated_at']),
        ];
    }, $rows);
}

function xbpo_append_log(PDO $pdo, string $action, string $targetType, string $receiptId, string $status, string $detail, string $actorEmail): array
{
    $id = 'log_' . bin2hex(random_bytes(8));
    $cleanDetail = substr($detail, 0, 500);
    $stmt = $pdo->prepare(
        'INSERT INTO sync_audit_logs (id, action, target_type, receipt_id, status, detail, actor_email) VALUES (?, ?, ?, ?, ?, ?, ?)'
    );
    $stmt->execute([$id, $action, $targetType, $receiptId, $status, $cleanDetail, $actorEmail]);
    return [
        'id' => $id,
        'action' => $action,
        'targetType' => $targetType,
        'receiptId' => $receiptId,
        'status' => $status,
        'detail' => $cleanDetail,
        'actorEmail' => $actorEmail,
        'createdAt' => xbpo_iso_date(gmdate('Y-m-d H:i:s')),
    ];
}

function xbpo_map_job(array $r): array
{
    return [
        'id' => $r['id'],
        'receiptId' => $r['receipt_id'],
        'fullName' => $r['full_name'],
        'email' => $r['email'],
        'phone' => $r['phone'],
        'city' => $r['city'],
        'role' => $r['role'],
        'experience' => $r['experience'],
        'education' => $r['education'] ?? '',
        'portfolio' => $r['portfolio'] ?? '',
        'message' => $r['message'] ?? '',
        'resumeName' => $r['resume_name'],
        'resumeMime' => $r['resume_mime'] ?? '',
        'resumeSize' => (int)($r['resume_size'] ?? 0),
        'driveFileId' => $r['drive_file_id'] ?? '',
        'driveFileUrl' => $r['drive_file_url'] ?? '',
        'driveSyncStatus' => $r['drive_sync_status'],
        'sheetSyncStatus' => $r['sheet_sync_status'],
        'sheetRowNumber' => $r['sheet_row_number'] !== null ? (int)$r['sheet_row_number'] : null,
        'syncError' => $r['sync_error'] ?? '',
        'reviewStatus' => $r['review_status'],
        'lastVerifiedAt' => xbpo_iso_date($r['last_verified_at']),
        'createdAt' => xbpo_iso_date($r['created_at']),
        'updatedAt' => xbpo_iso_date($r['updated_at']),
        'hasTransientCv' => xbpo_get_transient_cv($r['receipt_id']) !== null,
    ];
}

function xbpo_map_enquiry(array $r): array
{
    return [
        'id' => $r['id'],
        'receiptId' => $r['receipt_id'],
        'fullName' => $r['full_name'],
        'email' => $r['email'],
        'phone' => $r['phone'] ?? '',
        'company' => $r['company'] ?? '',
        'service' => $r['service'],
        'message' => $r['message'],
        'sheetSyncStatus' => $r['sheet_sync_status'],
        'sheetRowNumber' => $r['sheet_row_number'] !== null ? (int)$r['sheet_row_number'] : null,
        'syncError' => $r['sync_error'] ?? '',
        'reviewStatus' => $r['review_status'],
        'lastVerifiedAt' => xbpo_iso_date($r['last_verified_at']),
        'createdAt' => xbpo_iso_date($r['created_at']),
        'updatedAt' => xbpo_iso_date($r['updated_at']),
    ];
}

function xbpo_extract_spreadsheet_id(string $input): string
{
    $clean = xbpo_sanitize_text($input, 300);
    if ($clean === '') {
        return '';
    }
    if (preg_match('/docs\.google\.com\/spreadsheets\/d\/([a-zA-Z0-9_-]+)/', $clean, $m)) {
        return $m[1];
    }
    return $clean;
}

function xbpo_extract_drive_folder_id(string $input): string
{
    $clean = xbpo_sanitize_text($input, 300);
    if ($clean === '') {
        return '';
    }
    if (preg_match('/drive\.google\.com\/drive\/(?:u\/\d+\/)?folders\/([a-zA-Z0-9_-]+)/', $clean, $m)) {
        return $m[1];
    }
    return $clean;
}

try {
    // Public routes
    if ($method === 'GET' && $route === 'site-settings') {
        $pdo = xbpo_pdo();
        $s = xbpo_get_settings($pdo);
        $activeRoles = xbpo_list_roles($pdo, true);
        xbpo_json(200, [
            'instagramUrl' => $s['instagramUrl'],
            'facebookUrl' => $s['facebookUrl'],
            'googleUrl' => $s['googleUrl'],
            'contactEmail' => $s['contactEmail'],
            'contactPhone' => $s['contactPhone'],
            'appsScriptUrl' => $s['appsScriptUrl'],
            'careerRoles' => array_map(static function ($r) {
                return ['id' => $r['id'], 'name' => $r['name'], 'description' => $r['description']];
            }, $activeRoles),
        ]);
    }

    if ($method === 'GET' && $route === 'roles') {
        $pdo = xbpo_pdo();
        $roles = xbpo_list_roles($pdo, true);
        xbpo_json(200, [
            'roles' => array_map(static function ($r) {
                return ['id' => $r['id'], 'name' => $r['name'], 'description' => $r['description']];
            }, $roles),
        ]);
    }

    if ($method === 'POST' && $route === 'submissions') {
        xbpo_check_rate_limit('submit', 60, 12);
        $pdo = xbpo_pdo();
        $b = xbpo_body();
        $formType = xbpo_sanitize_text($b['formType'] ?? '', 20);

        if (!empty($b['website'])) {
            throw new InvalidArgumentException('Rejected automated submission.');
        }
        $consent = $b['consent'] ?? '';
        if ($consent !== 'on' && $consent !== true) {
            throw new InvalidArgumentException('Consent is required.');
        }
        $receiptId = xbpo_sanitize_text($b['requestId'] ?? '', 80);
        if (!xbpo_is_valid_receipt_id($receiptId)) {
            throw new InvalidArgumentException('Invalid receipt ID.');
        }

        if ($formType === 'career') {
            $activeRoles = xbpo_list_roles($pdo, true);
            $allowedRoles = array_column($activeRoles, 'name');

            $fullName = xbpo_sanitize_text($b['fullName'] ?? '', 100);
            $email = strtolower(xbpo_sanitize_text($b['email'] ?? '', 150));
            $phone = xbpo_sanitize_text($b['phone'] ?? '', 32);
            $city = xbpo_sanitize_text($b['city'] ?? '', 100);
            $role = xbpo_sanitize_text($b['role'] ?? '', 100);
            $experience = xbpo_sanitize_text($b['experience'] ?? '', 50);
            $education = xbpo_sanitize_text($b['education'] ?? '', 120);
            $portfolio = xbpo_sanitize_text($b['portfolio'] ?? '', 250);
            $message = xbpo_sanitize_text($b['message'] ?? '', 2000, true);

            foreach (compact('fullName', 'email', 'phone', 'city', 'role', 'experience', 'education', 'portfolio', 'message') as $k => $v) {
                xbpo_assert_no_sqli($v, $k);
            }
            if (strlen($fullName) < 2) throw new InvalidArgumentException('Full name must be at least 2 characters.');
            if (!xbpo_is_valid_email($email)) throw new InvalidArgumentException('Valid email address is required.');
            if (!xbpo_is_valid_phone($phone)) throw new InvalidArgumentException('Valid phone number is required.');
            if (strlen($city) < 2) throw new InvalidArgumentException('City is required.');
            if ($role === '' || !in_array($role, $allowedRoles, true)) throw new InvalidArgumentException('Please choose a valid active role.');
            if (!in_array($experience, XBPO_ALLOWED_EXPERIENCE, true)) throw new InvalidArgumentException('Please choose a valid experience level.');
            if ($portfolio !== '' && !xbpo_is_valid_http_url($portfolio, true)) throw new InvalidArgumentException('Portfolio URL must start with http:// or https://.');

            $cv = xbpo_validate_cv_upload((string)($b['resumeName'] ?? ''), (string)($b['resumeBase64'] ?? ''));
            xbpo_set_transient_cv($receiptId, $cv);

            $id = 'job_' . substr($receiptId, 0, 20);
            $stmt = $pdo->prepare(
                'INSERT IGNORE INTO job_applications
                 (id, receipt_id, full_name, email, phone, city, role, experience, education, portfolio, message, resume_name, resume_mime, resume_size, drive_sync_status, sheet_sync_status, review_status)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
            );
            $stmt->execute([
                $id, $receiptId, $fullName, $email, $phone, $city, $role, $experience, $education, $portfolio, $message,
                $cv['safeFileName'], $cv['mimeType'], $cv['sizeBytes'], 'pending', 'pending', 'new',
            ]);
            xbpo_append_log($pdo, 'application_received', 'career', $receiptId, 'ok', "Validated application from {$fullName} ({$role}); CV buffered temporarily for Google Drive sync.", $email);
            xbpo_json(201, ['ok' => true, 'receiptId' => $receiptId, 'type' => 'career', 'resumeName' => $cv['safeFileName']]);
        }

        if ($formType === 'contact') {
            $fullName = xbpo_sanitize_text($b['fullName'] ?? '', 100);
            $email = strtolower(xbpo_sanitize_text($b['email'] ?? '', 150));
            $phone = xbpo_sanitize_text($b['phone'] ?? '', 32);
            $company = xbpo_sanitize_text($b['company'] ?? '', 120);
            $service = xbpo_sanitize_text($b['service'] ?? '', 100);
            $message = xbpo_sanitize_text($b['message'] ?? '', 3000, true);

            foreach (compact('fullName', 'email', 'phone', 'company', 'service', 'message') as $k => $v) {
                xbpo_assert_no_sqli($v, $k);
            }
            if (strlen($fullName) < 2) throw new InvalidArgumentException('Full name must be at least 2 characters.');
            if (!xbpo_is_valid_email($email)) throw new InvalidArgumentException('Valid business email is required.');
            if ($phone !== '' && !xbpo_is_valid_phone($phone)) throw new InvalidArgumentException('Phone number format is invalid.');
            if (!in_array($service, XBPO_ALLOWED_SERVICES, true)) throw new InvalidArgumentException('Please select a valid service.');
            if (strlen($message) < 2) throw new InvalidArgumentException('Please enter your campaign requirement.');

            $id = 'enq_' . substr($receiptId, 0, 20);
            $stmt = $pdo->prepare(
                'INSERT IGNORE INTO contact_enquiries
                 (id, receipt_id, full_name, email, phone, company, service, message, sheet_sync_status, review_status)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
            );
            $stmt->execute([$id, $receiptId, $fullName, $email, $phone, $company, $service, $message, 'pending', 'new']);
            xbpo_append_log($pdo, 'enquiry_received', 'contact', $receiptId, 'ok', "Validated enquiry from {$fullName} ({$service}); queued for Google Sheets sync.", $email);
            xbpo_json(201, ['ok' => true, 'receiptId' => $receiptId, 'type' => 'contact']);
        }

        xbpo_json(400, ['error' => 'Invalid form submission type.']);
    }

    if ($method === 'POST' && preg_match('#^submissions/([A-Za-z0-9_-]+)/apps-script-status$#', $route, $m)) {
        xbpo_check_rate_limit('submit', 60, 20);
        $receiptId = $m[1];
        if (!xbpo_is_valid_receipt_id($receiptId)) {
            xbpo_json(400, ['error' => 'Invalid receipt ID.']);
        }
        $pdo = xbpo_pdo();
        $b = xbpo_body();
        $allowed = ['pending', 'synced', 'verified', 'error'];
        $nowSql = gmdate('Y-m-d H:i:s');

        $jStmt = $pdo->prepare('SELECT receipt_id, sheet_sync_status, drive_sync_status, sync_error FROM job_applications WHERE receipt_id = ? LIMIT 1');
        $jStmt->execute([$receiptId]);
        if ($row = $jStmt->fetch()) {
            $sheetStatus = in_array($b['sheetSyncStatus'] ?? '', $allowed, true) ? $b['sheetSyncStatus'] : $row['sheet_sync_status'];
            $driveStatus = in_array($b['driveSyncStatus'] ?? '', $allowed, true) ? $b['driveSyncStatus'] : $row['drive_sync_status'];
            $syncErr = isset($b['syncError']) && is_string($b['syncError']) ? xbpo_sanitize_text($b['syncError'], 500) : $row['sync_error'];
            $upd = $pdo->prepare('UPDATE job_applications SET sheet_sync_status = ?, drive_sync_status = ?, sync_error = ?, last_verified_at = ? WHERE receipt_id = ?');
            $upd->execute([$sheetStatus, $driveStatus, $syncErr, $nowSql, $receiptId]);
            if ($driveStatus === 'synced' || $driveStatus === 'verified') {
                xbpo_clear_transient_cv($receiptId);
            }
            xbpo_json(200, ['ok' => true, 'receiptId' => $receiptId]);
        }

        $eStmt = $pdo->prepare('SELECT receipt_id, sheet_sync_status, sync_error FROM contact_enquiries WHERE receipt_id = ? LIMIT 1');
        $eStmt->execute([$receiptId]);
        if ($row = $eStmt->fetch()) {
            $sheetStatus = in_array($b['sheetSyncStatus'] ?? '', $allowed, true) ? $b['sheetSyncStatus'] : $row['sheet_sync_status'];
            $syncErr = isset($b['syncError']) && is_string($b['syncError']) ? xbpo_sanitize_text($b['syncError'], 500) : $row['sync_error'];
            $upd = $pdo->prepare('UPDATE contact_enquiries SET sheet_sync_status = ?, sync_error = ?, last_verified_at = ? WHERE receipt_id = ?');
            $upd->execute([$sheetStatus, $syncErr, $nowSql, $receiptId]);
            xbpo_json(200, ['ok' => true, 'receiptId' => $receiptId]);
        }

        xbpo_json(400, ['error' => 'Submission not found.']);
    }

    // Admin login (Private Email & Password only)
    if ($method === 'POST' && $route === 'admin/login') {
        xbpo_check_rate_limit('login', 900, 20);
        $b = xbpo_body();
        $email = strtolower(xbpo_sanitize_text($b['email'] ?? '', 150));
        $password = (string)($b['password'] ?? '');
        xbpo_assert_no_sqli($email, 'email');
        if (!xbpo_is_valid_email($email) || strlen($password) < 4 || strlen($password) > 128) {
            xbpo_json(400, ['error' => 'Please enter a valid email and password.']);
        }
        $pdo = xbpo_pdo();
        $stmt = $pdo->prepare('SELECT * FROM admin_users WHERE email = ? LIMIT 1');
        $stmt->execute([$email]);
        $u = $stmt->fetch();
        if (!$u || !$u['active'] || !xbpo_verify_password($password, $u['password_hash'])) {
            xbpo_json(401, ['error' => 'Invalid email or password, or account disabled.']);
        }
        $user = [
            'id' => $u['id'],
            'email' => $u['email'],
            'name' => $u['name'],
            'role' => $u['role'],
            'active' => (bool)$u['active'],
        ];
        xbpo_set_session_cookie($user);
        xbpo_json(200, ['ok' => true, 'user' => $user]);
    }

    if ($method === 'POST' && $route === 'admin/logout') {
        xbpo_clear_session_cookie();
        xbpo_json(200, ['ok' => true]);
    }

    if ($method === 'GET' && $route === 'admin/me') {
        $user = xbpo_require_admin();
        $host = xbpo_env('MYSQL_HOST', 'localhost');
        $db = xbpo_env('MYSQL_DATABASE', '');
        xbpo_pdo();
        xbpo_json(200, [
            'ok' => true,
            'user' => $user,
            'databaseMode' => 'MariaDB (localhost:3306)',
            'dbStatus' => [
                'mode' => 'MariaDB (Hosting Connected)',
                'mysqlConfigured' => true,
                'mysqlActive' => true,
                'mysqlHost' => $host,
                'mysqlDatabase' => $db,
                'mysqlLastError' => '',
            ],
        ]);
    }

    if ($method === 'POST' && $route === 'admin/change-password') {
        $user = xbpo_require_admin();
        $b = xbpo_body();
        $curPw = (string)($b['currentPassword'] ?? '');
        $newPw = (string)($b['newPassword'] ?? '');
        if (strlen($newPw) < 8 || strlen($newPw) > 128) {
            xbpo_json(400, ['error' => 'New password must be 8–128 characters.']);
        }
        $pdo = xbpo_pdo();
        $stmt = $pdo->prepare('SELECT password_hash FROM admin_users WHERE email = ? LIMIT 1');
        $stmt->execute([$user['email']]);
        $row = $stmt->fetch();
        if (!$row || !xbpo_verify_password($curPw, $row['password_hash'])) {
            xbpo_json(400, ['error' => 'Current password is incorrect.']);
        }
        $upd = $pdo->prepare('UPDATE admin_users SET password_hash = ? WHERE email = ?');
        $upd->execute([password_hash($newPw, PASSWORD_BCRYPT), $user['email']]);
        xbpo_append_log($pdo, 'password_changed', 'settings', '', 'ok', "Password updated for {$user['email']}.", $user['email']);
        xbpo_json(200, ['ok' => true]);
    }

    if ($method === 'GET' && $route === 'admin/users') {
        xbpo_require_admin();
        $pdo = xbpo_pdo();
        $rows = $pdo->query('SELECT id, email, name, role, active, created_at, updated_at FROM admin_users ORDER BY created_at ASC')->fetchAll();
        $users = array_map(static function ($u) {
            return [
                'id' => $u['id'],
                'email' => $u['email'],
                'name' => $u['name'],
                'role' => $u['role'],
                'active' => (bool)$u['active'],
                'createdAt' => xbpo_iso_date($u['created_at']),
                'updatedAt' => xbpo_iso_date($u['updated_at']),
            ];
        }, $rows);
        xbpo_json(200, ['users' => $users]);
    }

    if ($method === 'POST' && $route === 'admin/users') {
        $user = xbpo_require_admin();
        xbpo_require_master($user);
        $b = xbpo_body();
        $email = strtolower(xbpo_sanitize_text($b['email'] ?? '', 150));
        $name = xbpo_sanitize_text($b['name'] ?? '', 100);
        $role = xbpo_sanitize_text($b['role'] ?? '', 20);
        $pw = (string)($b['password'] ?? '');
        xbpo_assert_no_sqli($email, 'email');
        xbpo_assert_no_sqli($name, 'name');
        if (!xbpo_is_valid_email($email)) xbpo_json(400, ['error' => 'Valid email is required.']);
        if (strlen($name) < 2) xbpo_json(400, ['error' => 'Name must be at least 2 characters.']);
        if (!in_array($role, ['admin', 'reviewer'], true)) xbpo_json(400, ['error' => 'Role must be admin or reviewer.']);
        if (strlen($pw) < 8 || strlen($pw) > 128) xbpo_json(400, ['error' => 'Password must be between 8 and 128 characters.']);

        $pdo = xbpo_pdo();
        $dup = $pdo->prepare('SELECT id FROM admin_users WHERE email = ? LIMIT 1');
        $dup->execute([$email]);
        if ($dup->fetch()) xbpo_json(400, ['error' => 'An admin user with this email already exists.']);

        $id = 'adm_' . bin2hex(random_bytes(8));
        $ins = $pdo->prepare('INSERT INTO admin_users (id, email, name, role, password_hash, active) VALUES (?, ?, ?, ?, ?, 1)');
        $ins->execute([$id, $email, $name, $role, password_hash($pw, PASSWORD_BCRYPT)]);
        xbpo_append_log($pdo, 'admin_user_created', 'settings', '', 'ok', "Added {$role} user {$email}.", $user['email']);
        $now = xbpo_iso_date(gmdate('Y-m-d H:i:s'));
        xbpo_json(201, ['user' => ['id' => $id, 'email' => $email, 'name' => $name, 'role' => $role, 'active' => true, 'createdAt' => $now, 'updatedAt' => $now]]);
    }

    if ($method === 'PATCH' && preg_match('#^admin/users/([a-zA-Z0-9_-]+)$#', $route, $m)) {
        $user = xbpo_require_admin();
        xbpo_require_master($user);
        $id = $m[1];
        $b = xbpo_body();
        $pdo = xbpo_pdo();
        $stmt = $pdo->prepare('SELECT id, email, name, role, active FROM admin_users WHERE id = ? LIMIT 1');
        $stmt->execute([$id]);
        $cur = $stmt->fetch();
        if (!$cur) xbpo_json(400, ['error' => 'Admin user not found.']);
        $isMaster = strtolower($cur['email']) === XBPO_MASTER_EMAIL;
        if ($isMaster && isset($b['active']) && $b['active'] === false) {
            xbpo_json(400, ['error' => 'Master administrator cannot be deactivated.']);
        }
        $nextActive = isset($b['active']) && is_bool($b['active']) ? $b['active'] : (bool)$cur['active'];
        $nextRole = (!$isMaster && isset($b['role']) && in_array($b['role'], ['admin', 'reviewer'], true)) ? $b['role'] : $cur['role'];
        $upd = $pdo->prepare('UPDATE admin_users SET role = ?, active = ? WHERE id = ?');
        $upd->execute([$nextRole, $nextActive ? 1 : 0, $id]);
        xbpo_json(200, ['user' => ['id' => $cur['id'], 'email' => $cur['email'], 'name' => $cur['name'], 'role' => $nextRole, 'active' => $nextActive]]);
    }

    if ($method === 'POST' && preg_match('#^admin/users/([a-zA-Z0-9_-]+)/reset-password$#', $route, $m)) {
        $user = xbpo_require_admin();
        xbpo_require_master($user);
        $id = $m[1];
        $b = xbpo_body();
        $newPw = (string)($b['newPassword'] ?? '');
        if (strlen($newPw) < 8 || strlen($newPw) > 128) {
            xbpo_json(400, ['error' => 'New password must be 8–128 characters.']);
        }
        $pdo = xbpo_pdo();
        $stmt = $pdo->prepare('SELECT id, email FROM admin_users WHERE id = ? LIMIT 1');
        $stmt->execute([$id]);
        $target = $stmt->fetch();
        if (!$target) xbpo_json(400, ['error' => 'Admin user not found.']);
        $upd = $pdo->prepare('UPDATE admin_users SET password_hash = ? WHERE id = ?');
        $upd->execute([password_hash($newPw, PASSWORD_BCRYPT), $id]);
        xbpo_append_log($pdo, 'admin_password_reset', 'settings', '', 'ok', "Master administrator reset password for {$target['email']}.", $user['email']);
        xbpo_json(200, ['ok' => true, 'email' => $target['email']]);
    }

    if ($method === 'DELETE' && preg_match('#^admin/users/([a-zA-Z0-9_-]+)$#', $route, $m)) {
        $user = xbpo_require_admin();
        xbpo_require_master($user);
        $id = $m[1];
        $pdo = xbpo_pdo();
        $stmt = $pdo->prepare('SELECT email, role FROM admin_users WHERE id = ? LIMIT 1');
        $stmt->execute([$id]);
        $target = $stmt->fetch();
        if (!$target) xbpo_json(400, ['error' => 'Admin user not found.']);
        if (strtolower($target['email']) === XBPO_MASTER_EMAIL || $target['role'] === 'master') {
            xbpo_json(400, ['error' => 'Master administrator cannot be deleted.']);
        }
        $del = $pdo->prepare('DELETE FROM admin_users WHERE id = ?');
        $del->execute([$id]);
        xbpo_json(200, ['ok' => true]);
    }

    if ($method === 'GET' && $route === 'admin/submissions') {
        xbpo_require_admin();
        $pdo = xbpo_pdo();
        $jobRows = $pdo->query('SELECT * FROM job_applications ORDER BY created_at DESC LIMIT 500')->fetchAll();
        $enqRows = $pdo->query('SELECT * FROM contact_enquiries ORDER BY created_at DESC LIMIT 500')->fetchAll();
        xbpo_json(200, [
            'jobs' => array_map('xbpo_map_job', $jobRows),
            'enquiries' => array_map('xbpo_map_enquiry', $enqRows),
        ]);
    }

    if ($method === 'GET' && preg_match('#^admin/submissions/([A-Za-z0-9_-]+)/pending-cv$#', $route, $m)) {
        xbpo_require_admin();
        $receiptId = $m[1];
        if (!xbpo_is_valid_receipt_id($receiptId)) xbpo_json(400, ['error' => 'Invalid receipt ID.']);
        $cv = xbpo_get_transient_cv($receiptId);
        if (!$cv) {
            xbpo_json(404, ['error' => 'No pending CV buffer found (it may already be synced to Google Drive).']);
        }
        xbpo_json(200, [
            'safeFileName' => $cv['safeFileName'],
            'mimeType' => $cv['mimeType'],
            'sizeBytes' => (int)$cv['sizeBytes'],
            'base64' => $cv['base64'],
        ]);
    }

    if ($method === 'POST' && preg_match('#^admin/submissions/([A-Za-z0-9_-]+)/sync-status$#', $route, $m)) {
        xbpo_require_admin();
        $receiptId = $m[1];
        if (!xbpo_is_valid_receipt_id($receiptId)) xbpo_json(400, ['error' => 'Invalid receipt ID.']);
        $b = xbpo_body();
        $pdo = xbpo_pdo();
        $syncAllowed = ['pending', 'synced', 'verified', 'error'];
        $reviewAllowed = ['new', 'reviewed', 'shortlisted', 'rejected', 'contacted', 'qualified', 'closed'];

        $jStmt = $pdo->prepare('SELECT * FROM job_applications WHERE receipt_id = ? LIMIT 1');
        $jStmt->execute([$receiptId]);
        if ($r = $jStmt->fetch()) {
            $driveFileId = is_string($b['driveFileId'] ?? null) ? xbpo_sanitize_text($b['driveFileId'], 150) : $r['drive_file_id'];
            $driveFileUrl = (is_string($b['driveFileUrl'] ?? null) && xbpo_is_valid_http_url($b['driveFileUrl'], true)) ? trim($b['driveFileUrl']) : $r['drive_file_url'];
            $driveStatus = in_array($b['driveSyncStatus'] ?? '', $syncAllowed, true) ? $b['driveSyncStatus'] : $r['drive_sync_status'];
            $sheetStatus = in_array($b['sheetSyncStatus'] ?? '', $syncAllowed, true) ? $b['sheetSyncStatus'] : $r['sheet_sync_status'];
            $rowNum = (isset($b['sheetRowNumber']) && is_numeric($b['sheetRowNumber']) && $b['sheetRowNumber'] >= 0) ? (int)$b['sheetRowNumber'] : $r['sheet_row_number'];
            $syncErr = is_string($b['syncError'] ?? null) ? xbpo_sanitize_text($b['syncError'], 500) : $r['sync_error'];
            $reviewStatus = in_array($b['reviewStatus'] ?? '', $reviewAllowed, true) ? $b['reviewStatus'] : $r['review_status'];
            $lastVer = is_string($b['lastVerifiedAt'] ?? null) && $b['lastVerifiedAt'] !== '' ? gmdate('Y-m-d H:i:s', strtotime($b['lastVerifiedAt']) ?: time()) : $r['last_verified_at'];

            $upd = $pdo->prepare(
                'UPDATE job_applications SET drive_file_id = ?, drive_file_url = ?, drive_sync_status = ?, sheet_sync_status = ?, sheet_row_number = ?, sync_error = ?, review_status = ?, last_verified_at = ? WHERE receipt_id = ?'
            );
            $upd->execute([$driveFileId, $driveFileUrl, $driveStatus, $sheetStatus, $rowNum, $syncErr, $reviewStatus, $lastVer, $receiptId]);
            if ($driveStatus === 'synced' || $driveStatus === 'verified') {
                xbpo_clear_transient_cv($receiptId);
            }
            $jStmt->execute([$receiptId]);
            xbpo_json(200, ['submission' => xbpo_map_job($jStmt->fetch())]);
        }

        $eStmt = $pdo->prepare('SELECT * FROM contact_enquiries WHERE receipt_id = ? LIMIT 1');
        $eStmt->execute([$receiptId]);
        if ($r = $eStmt->fetch()) {
            $sheetStatus = in_array($b['sheetSyncStatus'] ?? '', $syncAllowed, true) ? $b['sheetSyncStatus'] : $r['sheet_sync_status'];
            $rowNum = (isset($b['sheetRowNumber']) && is_numeric($b['sheetRowNumber']) && $b['sheetRowNumber'] >= 0) ? (int)$b['sheetRowNumber'] : $r['sheet_row_number'];
            $syncErr = is_string($b['syncError'] ?? null) ? xbpo_sanitize_text($b['syncError'], 500) : $r['sync_error'];
            $reviewStatus = in_array($b['reviewStatus'] ?? '', $reviewAllowed, true) ? $b['reviewStatus'] : $r['review_status'];
            $lastVer = is_string($b['lastVerifiedAt'] ?? null) && $b['lastVerifiedAt'] !== '' ? gmdate('Y-m-d H:i:s', strtotime($b['lastVerifiedAt']) ?: time()) : $r['last_verified_at'];

            $upd = $pdo->prepare(
                'UPDATE contact_enquiries SET sheet_sync_status = ?, sheet_row_number = ?, sync_error = ?, review_status = ?, last_verified_at = ? WHERE receipt_id = ?'
            );
            $upd->execute([$sheetStatus, $rowNum, $syncErr, $reviewStatus, $lastVer, $receiptId]);
            $eStmt->execute([$receiptId]);
            xbpo_json(200, ['submission' => xbpo_map_enquiry($eStmt->fetch())]);
        }

        xbpo_json(400, ['error' => 'Submission not found.']);
    }

    if ($method === 'PATCH' && preg_match('#^admin/submissions/([A-Za-z0-9_-]+)$#', $route, $m)) {
        $user = xbpo_require_admin();
        xbpo_require_editor($user);
        $receiptId = $m[1];
        if (!xbpo_is_valid_receipt_id($receiptId)) xbpo_json(400, ['error' => 'Invalid receipt ID.']);
        $b = xbpo_body();
        $pdo = xbpo_pdo();

        $jStmt = $pdo->prepare('SELECT * FROM job_applications WHERE receipt_id = ? LIMIT 1');
        $jStmt->execute([$receiptId]);
        $job = $jStmt->fetch();

        $eStmt = $pdo->prepare('SELECT * FROM contact_enquiries WHERE receipt_id = ? LIMIT 1');
        $eStmt->execute([$receiptId]);
        $enq = $eStmt->fetch();

        if (!$job && !$enq) xbpo_json(404, ['error' => 'Submission not found.']);

        $isJob = (bool)$job;
        $cur = $isJob ? $job : $enq;

        $fullName = isset($b['fullName']) ? xbpo_sanitize_text($b['fullName'], 100) : $cur['full_name'];
        $email = isset($b['email']) ? strtolower(xbpo_sanitize_text($b['email'], 150)) : $cur['email'];
        $phone = isset($b['phone']) ? xbpo_sanitize_text($b['phone'], 32) : $cur['phone'];
        $message = isset($b['message']) ? xbpo_sanitize_text($b['message'], 3000, true) : ($cur['message'] ?? '');

        foreach (compact('fullName', 'email', 'phone', 'message') as $k => $v) xbpo_assert_no_sqli($v, $k);
        if (strlen($fullName) < 2) xbpo_json(400, ['error' => 'Full name must be at least 2 characters.']);
        if (!xbpo_is_valid_email($email)) xbpo_json(400, ['error' => 'Invalid email address.']);
        if (($isJob || $phone !== '') && !xbpo_is_valid_phone($phone)) xbpo_json(400, ['error' => 'Invalid phone number.']);

        if ($isJob) {
            $city = isset($b['city']) ? xbpo_sanitize_text($b['city'], 100) : $cur['city'];
            $role = isset($b['role']) ? xbpo_sanitize_text($b['role'], 100) : $cur['role'];
            $experience = isset($b['experience']) ? xbpo_sanitize_text($b['experience'], 50) : $cur['experience'];
            $education = isset($b['education']) ? xbpo_sanitize_text($b['education'], 120) : $cur['education'];
            $portfolio = isset($b['portfolio']) ? xbpo_sanitize_text($b['portfolio'], 250) : $cur['portfolio'];
            $reviewStatus = $b['reviewStatus'] ?? $cur['review_status'];

            foreach (compact('city', 'role', 'education', 'portfolio') as $k => $v) xbpo_assert_no_sqli($v, $k);
            if (strlen($city) < 2) xbpo_json(400, ['error' => 'City is required.']);
            if (isset($b['role'])) {
                $allRoleNames = array_column(xbpo_list_roles($pdo, false), 'name');
                if (!in_array($role, $allRoleNames, true)) xbpo_json(400, ['error' => 'Invalid role selected.']);
            }
            if (!in_array($experience, XBPO_ALLOWED_EXPERIENCE, true)) xbpo_json(400, ['error' => 'Invalid experience level.']);
            if ($portfolio !== '' && !xbpo_is_valid_http_url($portfolio, true)) xbpo_json(400, ['error' => 'Invalid portfolio URL.']);
            if (!in_array($reviewStatus, ['new', 'reviewed', 'shortlisted', 'rejected'], true)) xbpo_json(400, ['error' => 'Invalid job review status.']);

            $upd = $pdo->prepare(
                'UPDATE job_applications SET full_name = ?, email = ?, phone = ?, city = ?, role = ?, experience = ?, education = ?, portfolio = ?, message = ?, review_status = ? WHERE receipt_id = ?'
            );
            $upd->execute([$fullName, $email, $phone, $city, $role, $experience, $education, $portfolio, $message, $reviewStatus, $receiptId]);
            xbpo_append_log($pdo, 'submission_edited', 'career', $receiptId, 'ok', "Updated fields on application {$receiptId}.", $user['email']);
            $jStmt->execute([$receiptId]);
            xbpo_json(200, ['submission' => xbpo_map_job($jStmt->fetch())]);
        } else {
            if (strlen($message) < 2) xbpo_json(400, ['error' => 'Message cannot be empty.']);
            $company = isset($b['company']) ? xbpo_sanitize_text($b['company'], 120) : $cur['company'];
            $service = isset($b['service']) ? xbpo_sanitize_text($b['service'], 100) : $cur['service'];
            $reviewStatus = $b['reviewStatus'] ?? $cur['review_status'];
            xbpo_assert_no_sqli($company, 'company');
            if (!in_array($service, XBPO_ALLOWED_SERVICES, true)) xbpo_json(400, ['error' => 'Invalid service selected.']);
            if (!in_array($reviewStatus, ['new', 'contacted', 'qualified', 'closed'], true)) xbpo_json(400, ['error' => 'Invalid enquiry status.']);

            $upd = $pdo->prepare(
                'UPDATE contact_enquiries SET full_name = ?, email = ?, phone = ?, company = ?, service = ?, message = ?, review_status = ? WHERE receipt_id = ?'
            );
            $upd->execute([$fullName, $email, $phone, $company, $service, $message, $reviewStatus, $receiptId]);
            xbpo_append_log($pdo, 'submission_edited', 'contact', $receiptId, 'ok', "Updated fields on enquiry {$receiptId}.", $user['email']);
            $eStmt->execute([$receiptId]);
            xbpo_json(200, ['submission' => xbpo_map_enquiry($eStmt->fetch())]);
        }
    }

    if ($method === 'GET' && preg_match('#^admin/export/(jobs|enquiries)$#', $route, $m)) {
        xbpo_require_admin();
        $type = $m[1];
        $pdo = xbpo_pdo();
        $lines = [];
        if ($type === 'jobs') {
            $lines[] = implode(',', array_map('xbpo_csv_cell', [
                'Receipt ID', 'Full Name', 'Email', 'Phone', 'City', 'Role', 'Experience', 'Qualification',
                'Portfolio', 'Message', 'CV Filename', 'Drive CV URL', 'Sheet Sync Status', 'Drive Sync Status',
                'Review Status', 'Received At',
            ]));
            foreach ($pdo->query('SELECT * FROM job_applications ORDER BY created_at DESC LIMIT 500')->fetchAll() as $j) {
                $lines[] = implode(',', array_map('xbpo_csv_cell', [
                    $j['receipt_id'], $j['full_name'], $j['email'], $j['phone'], $j['city'], $j['role'],
                    $j['experience'], $j['education'], $j['portfolio'], $j['message'], $j['resume_name'],
                    $j['drive_file_url'], $j['sheet_sync_status'], $j['drive_sync_status'], $j['review_status'],
                    xbpo_iso_date($j['created_at']),
                ]));
            }
        } else {
            $lines[] = implode(',', array_map('xbpo_csv_cell', [
                'Receipt ID', 'Full Name', 'Email', 'Phone', 'Company', 'Service', 'Message',
                'Sheet Sync Status', 'Review Status', 'Received At',
            ]));
            foreach ($pdo->query('SELECT * FROM contact_enquiries ORDER BY created_at DESC LIMIT 500')->fetchAll() as $e) {
                $lines[] = implode(',', array_map('xbpo_csv_cell', [
                    $e['receipt_id'], $e['full_name'], $e['email'], $e['phone'], $e['company'], $e['service'],
                    $e['message'], $e['sheet_sync_status'], $e['review_status'], xbpo_iso_date($e['created_at']),
                ]));
            }
        }
        header('Content-Type: text/csv; charset=utf-8');
        header("Content-Disposition: attachment; filename=\"xbpo-{$type}-export.csv\"");
        echo "\xEF\xBB\xBF" . implode("\r\n", $lines);
        exit;
    }

    if ($method === 'DELETE' && preg_match('#^admin/submissions/([A-Za-z0-9_-]+)$#', $route, $m)) {
        $user = xbpo_require_admin();
        xbpo_require_master($user);
        $receiptId = $m[1];
        if (!xbpo_is_valid_receipt_id($receiptId)) xbpo_json(400, ['error' => 'Invalid receipt ID.']);
        $pdo = xbpo_pdo();
        xbpo_clear_transient_cv($receiptId);
        $pdo->prepare('DELETE FROM job_applications WHERE receipt_id = ?')->execute([$receiptId]);
        $pdo->prepare('DELETE FROM contact_enquiries WHERE receipt_id = ?')->execute([$receiptId]);
        xbpo_append_log($pdo, 'submission_deleted', 'workspace', $receiptId, 'warning', "Removed record {$receiptId} from portal queue.", $user['email']);
        xbpo_json(200, ['ok' => true]);
    }

    if ($method === 'GET' && $route === 'admin/settings') {
        xbpo_require_admin();
        xbpo_json(200, ['settings' => xbpo_get_settings(xbpo_pdo())]);
    }

    if ($method === 'PUT' && $route === 'admin/settings') {
        $user = xbpo_require_admin();
        xbpo_require_editor($user);
        $b = xbpo_body();
        $instagramUrl = xbpo_sanitize_text($b['instagramUrl'] ?? '', 300);
        $facebookUrl = xbpo_sanitize_text($b['facebookUrl'] ?? '', 300);
        $googleUrl = xbpo_sanitize_text($b['googleUrl'] ?? '', 300);
        $contactEmail = strtolower(xbpo_sanitize_text($b['contactEmail'] ?? '', 150));
        $contactPhone = xbpo_sanitize_text($b['contactPhone'] ?? '', 32);
        $appsScriptUrl = xbpo_sanitize_text($b['appsScriptUrl'] ?? '', 300);
        $spreadsheetId = xbpo_extract_spreadsheet_id((string)($b['spreadsheetId'] ?? ''));
        $driveFolderId = xbpo_extract_drive_folder_id((string)($b['driveFolderId'] ?? ''));

        foreach (compact('instagramUrl', 'facebookUrl', 'googleUrl', 'contactEmail', 'contactPhone', 'appsScriptUrl', 'spreadsheetId', 'driveFolderId') as $k => $v) {
            xbpo_assert_no_sqli($v, $k);
        }
        if (!xbpo_is_valid_http_url($instagramUrl)) xbpo_json(400, ['error' => 'Instagram URL must start with http:// or https://.']);
        if (!xbpo_is_valid_http_url($facebookUrl)) xbpo_json(400, ['error' => 'Facebook URL must start with http:// or https://.']);
        if (!xbpo_is_valid_http_url($googleUrl)) xbpo_json(400, ['error' => 'Google URL must start with http:// or https://.']);
        if (!xbpo_is_valid_email($contactEmail)) xbpo_json(400, ['error' => 'Invalid public contact email.']);
        if (!xbpo_is_valid_phone($contactPhone)) xbpo_json(400, ['error' => 'Invalid public phone number.']);
        if ($appsScriptUrl !== '' && !preg_match('#^https://script\.google\.com/macros/s/[a-zA-Z0-9_-]+/exec$#', $appsScriptUrl)) {
            xbpo_json(400, ['error' => 'Apps Script URL must be a valid Google Apps Script /exec URL.']);
        }
        if ($spreadsheetId !== '' && !preg_match('/^[a-zA-Z0-9_-]{10,150}$/', $spreadsheetId)) {
            xbpo_json(400, ['error' => 'Invalid Google Spreadsheet URL or ID format.']);
        }
        if ($driveFolderId !== '' && !preg_match('/^[a-zA-Z0-9_-]{10,150}$/', $driveFolderId)) {
            xbpo_json(400, ['error' => 'Invalid Google Drive Folder URL or ID format.']);
        }

        $pdo = xbpo_pdo();
        $upd = $pdo->prepare(
            'UPDATE site_settings
             SET instagram_url = ?, facebook_url = ?, google_url = ?, contact_email = ?, contact_phone = ?,
                 apps_script_url = ?, spreadsheet_id = ?, drive_folder_id = ?, updated_by = ?
             WHERE setting_key = ?'
        );
        $upd->execute([$instagramUrl, $facebookUrl, $googleUrl, $contactEmail, $contactPhone, $appsScriptUrl, $spreadsheetId, $driveFolderId, $user['email'], 'public']);
        xbpo_append_log($pdo, 'settings_updated', 'settings', '', 'ok', 'Updated social media links, contact details, or active Google Sheet/Drive target.', $user['email']);
        xbpo_json(200, ['settings' => xbpo_get_settings($pdo)]);
    }

    if ($method === 'GET' && $route === 'admin/logs') {
        xbpo_require_admin();
        $pdo = xbpo_pdo();
        $rows = $pdo->query('SELECT * FROM sync_audit_logs ORDER BY created_at DESC LIMIT 100')->fetchAll();
        $logs = array_map(static function ($r) {
            return [
                'id' => $r['id'],
                'action' => $r['action'],
                'targetType' => $r['target_type'],
                'receiptId' => $r['receipt_id'] ?? '',
                'status' => $r['status'],
                'detail' => $r['detail'],
                'actorEmail' => $r['actor_email'],
                'createdAt' => xbpo_iso_date($r['created_at']),
            ];
        }, $rows);
        xbpo_json(200, ['logs' => $logs]);
    }

    if ($method === 'POST' && $route === 'admin/logs') {
        $user = xbpo_require_admin();
        $b = xbpo_body();
        $action = xbpo_sanitize_text($b['action'] ?? '', 80);
        $targetType = xbpo_sanitize_text($b['targetType'] ?? '', 20);
        $receiptId = xbpo_sanitize_text($b['receiptId'] ?? '', 80);
        $status = xbpo_sanitize_text($b['status'] ?? '', 20);
        $detail = xbpo_sanitize_text($b['detail'] ?? '', 500);
        if ($action === '' || !in_array($targetType, ['career', 'contact', 'workspace', 'settings'], true) || !in_array($status, ['ok', 'warning', 'error'], true)) {
            xbpo_json(400, ['error' => 'Invalid audit log entry.']);
        }
        $log = xbpo_append_log(xbpo_pdo(), $action, $targetType, $receiptId, $status, $detail, $user['email']);
        xbpo_json(201, ['log' => $log]);
    }

    if ($method === 'GET' && $route === 'admin/roles') {
        xbpo_require_admin();
        xbpo_json(200, ['roles' => xbpo_list_roles(xbpo_pdo(), false)]);
    }

    if ($method === 'POST' && $route === 'admin/roles') {
        $user = xbpo_require_admin();
        xbpo_require_editor($user);
        $b = xbpo_body();
        $name = xbpo_sanitize_text($b['name'] ?? '', 100);
        $desc = xbpo_sanitize_text($b['description'] ?? '', 255);
        $active = isset($b['active']) ? (bool)$b['active'] : true;
        $sortOrder = isset($b['sortOrder']) && is_numeric($b['sortOrder']) ? (int)$b['sortOrder'] : 0;
        xbpo_assert_no_sqli($name, 'name');
        xbpo_assert_no_sqli($desc, 'description');
        if (strlen($name) < 2) xbpo_json(400, ['error' => 'Role name must be at least 2 characters.']);

        $pdo = xbpo_pdo();
        $dup = $pdo->prepare('SELECT id FROM career_roles WHERE LOWER(name) = LOWER(?) LIMIT 1');
        $dup->execute([$name]);
        if ($dup->fetch()) xbpo_json(400, ['error' => 'A career role with this name already exists.']);

        $id = 'role_' . bin2hex(random_bytes(6));
        $ins = $pdo->prepare('INSERT INTO career_roles (id, name, description, active, sort_order) VALUES (?, ?, ?, ?, ?)');
        $ins->execute([$id, $name, $desc, $active ? 1 : 0, $sortOrder]);
        xbpo_append_log($pdo, 'career_role_created', 'settings', '', 'ok', "Added career form role \"{$name}\".", $user['email']);
        $now = xbpo_iso_date(gmdate('Y-m-d H:i:s'));
        xbpo_json(201, ['role' => ['id' => $id, 'name' => $name, 'description' => $desc, 'active' => $active, 'sortOrder' => $sortOrder, 'createdAt' => $now, 'updatedAt' => $now]]);
    }

    if ($method === 'PATCH' && preg_match('#^admin/roles/([a-zA-Z0-9_-]+)$#', $route, $m)) {
        $user = xbpo_require_admin();
        xbpo_require_editor($user);
        $id = $m[1];
        $b = xbpo_body();
        $pdo = xbpo_pdo();
        $stmt = $pdo->prepare('SELECT * FROM career_roles WHERE id = ? LIMIT 1');
        $stmt->execute([$id]);
        $cur = $stmt->fetch();
        if (!$cur) xbpo_json(400, ['error' => 'Career role not found.']);

        $nextName = isset($b['name']) ? xbpo_sanitize_text($b['name'], 100) : $cur['name'];
        xbpo_assert_no_sqli($nextName, 'name');
        if (strlen($nextName) < 2) xbpo_json(400, ['error' => 'Role name must be at least 2 characters.']);
        if (strtolower($nextName) !== strtolower($cur['name'])) {
            $dup = $pdo->prepare('SELECT id FROM career_roles WHERE LOWER(name) = LOWER(?) AND id <> ? LIMIT 1');
            $dup->execute([$nextName, $id]);
            if ($dup->fetch()) xbpo_json(400, ['error' => 'Another role with this name already exists.']);
        }
        $nextDesc = isset($b['description']) ? xbpo_sanitize_text($b['description'], 255) : $cur['description'];
        xbpo_assert_no_sqli($nextDesc, 'description');
        $nextActive = isset($b['active']) && is_bool($b['active']) ? $b['active'] : (bool)$cur['active'];
        $nextOrder = isset($b['sortOrder']) && is_numeric($b['sortOrder']) ? (int)$b['sortOrder'] : (int)$cur['sort_order'];

        $upd = $pdo->prepare('UPDATE career_roles SET name = ?, description = ?, active = ?, sort_order = ? WHERE id = ?');
        $upd->execute([$nextName, $nextDesc, $nextActive ? 1 : 0, $nextOrder, $id]);
        $activeText = $nextActive ? 'true' : 'false';
        xbpo_append_log($pdo, 'career_role_updated', 'settings', '', 'ok', "Updated career role \"{$nextName}\" (active={$activeText}).", $user['email']);
        xbpo_json(200, ['role' => ['id' => $id, 'name' => $nextName, 'description' => $nextDesc, 'active' => $nextActive, 'sortOrder' => $nextOrder]]);
    }

    if ($method === 'DELETE' && preg_match('#^admin/roles/([a-zA-Z0-9_-]+)$#', $route, $m)) {
        $user = xbpo_require_admin();
        xbpo_require_editor($user);
        $id = $m[1];
        $pdo = xbpo_pdo();
        $stmt = $pdo->prepare('SELECT id FROM career_roles WHERE id = ? LIMIT 1');
        $stmt->execute([$id]);
        if (!$stmt->fetch()) xbpo_json(400, ['error' => 'Career role not found.']);
        $cnt = (int)$pdo->query('SELECT COUNT(*) FROM career_roles')->fetchColumn();
        if ($cnt <= 1) xbpo_json(400, ['error' => 'At least one career role must remain.']);
        $pdo->prepare('DELETE FROM career_roles WHERE id = ?')->execute([$id]);
        xbpo_append_log($pdo, 'career_role_deleted', 'settings', '', 'warning', "Deleted career role {$id}.", $user['email']);
        xbpo_json(200, ['ok' => true]);
    }

    if ($method === 'GET' && $route === 'admin/mariadb-schema') {
        xbpo_require_admin();
        $schemaPath = __DIR__ . '/mariadb_schema.sql';
        if (!is_file($schemaPath)) {
            xbpo_json(404, ['error' => 'Schema file not found.']);
        }
        if (($_GET['download'] ?? '') === '1') {
            header('Content-Type: application/sql; charset=utf-8');
            header('Content-Disposition: attachment; filename="xbpo_mariadb_schema.sql"');
        } else {
            header('Content-Type: text/plain; charset=utf-8');
        }
        readfile($schemaPath);
        exit;
    }

    xbpo_json(404, ['error' => 'API endpoint not found.']);
} catch (InvalidArgumentException $e) {
    xbpo_json(400, ['error' => $e->getMessage()]);
} catch (Throwable $e) {
    xbpo_json(500, ['error' => $e->getMessage() ?: 'Internal server error.']);
}
