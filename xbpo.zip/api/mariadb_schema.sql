-- XBPO Communications - Hardened MariaDB v10.6.28 Schema (localhost:3306)
-- Import this file directly into your selected MariaDB database in Plesk / phpMyAdmin.
-- Charset: utf8mb4 for full Unicode safety. Use ONLY prepared statements (?) in application code.

CREATE TABLE IF NOT EXISTS `admin_users` (
  `id` VARCHAR(64) NOT NULL,
  `email` VARCHAR(150) NOT NULL,
  `name` VARCHAR(100) NOT NULL,
  `role` ENUM('master', 'admin', 'reviewer') NOT NULL DEFAULT 'admin',
  `password_hash` VARCHAR(255) NOT NULL,
  `active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_admin_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `site_settings` (
  `setting_key` VARCHAR(64) NOT NULL,
  `instagram_url` VARCHAR(300) NOT NULL,
  `facebook_url` VARCHAR(300) NOT NULL,
  `google_url` VARCHAR(300) NOT NULL,
  `contact_email` VARCHAR(150) NOT NULL,
  `contact_phone` VARCHAR(32) NOT NULL,
  `apps_script_url` VARCHAR(300) NOT NULL DEFAULT '',
  `spreadsheet_id` VARCHAR(150) NOT NULL DEFAULT '',
  `drive_folder_id` VARCHAR(150) NOT NULL DEFAULT '',
  `updated_by` VARCHAR(150) NOT NULL,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `job_applications` (
  `id` VARCHAR(64) NOT NULL,
  `receipt_id` VARCHAR(80) NOT NULL,
  `full_name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(150) NOT NULL,
  `phone` VARCHAR(32) NOT NULL,
  `city` VARCHAR(100) NOT NULL,
  `role` VARCHAR(100) NOT NULL,
  `experience` VARCHAR(50) NOT NULL,
  `education` VARCHAR(120) NOT NULL DEFAULT '',
  `portfolio` VARCHAR(250) NOT NULL DEFAULT '',
  `message` TEXT NULL,
  `resume_name` VARCHAR(200) NOT NULL,
  `resume_mime` VARCHAR(120) NOT NULL DEFAULT '',
  `resume_size` INT UNSIGNED NOT NULL DEFAULT 0,
  `drive_file_id` VARCHAR(150) NOT NULL DEFAULT '',
  `drive_file_url` VARCHAR(300) NOT NULL DEFAULT '',
  `drive_sync_status` ENUM('pending', 'synced', 'verified', 'error') NOT NULL DEFAULT 'pending',
  `sheet_sync_status` ENUM('pending', 'synced', 'verified', 'error') NOT NULL DEFAULT 'pending',
  `sheet_row_number` INT UNSIGNED NULL,
  `sync_error` VARCHAR(500) NOT NULL DEFAULT '',
  `review_status` ENUM('new', 'reviewed', 'shortlisted', 'rejected') NOT NULL DEFAULT 'new',
  `last_verified_at` DATETIME NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_job_receipt` (`receipt_id`),
  KEY `idx_job_role` (`role`),
  KEY `idx_job_sync` (`sheet_sync_status`, `drive_sync_status`),
  KEY `idx_job_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `contact_enquiries` (
  `id` VARCHAR(64) NOT NULL,
  `receipt_id` VARCHAR(80) NOT NULL,
  `full_name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(150) NOT NULL,
  `phone` VARCHAR(32) NOT NULL DEFAULT '',
  `company` VARCHAR(120) NOT NULL DEFAULT '',
  `service` VARCHAR(100) NOT NULL,
  `message` TEXT NOT NULL,
  `sheet_sync_status` ENUM('pending', 'synced', 'verified', 'error') NOT NULL DEFAULT 'pending',
  `sheet_row_number` INT UNSIGNED NULL,
  `sync_error` VARCHAR(500) NOT NULL DEFAULT '',
  `review_status` ENUM('new', 'contacted', 'qualified', 'closed') NOT NULL DEFAULT 'new',
  `last_verified_at` DATETIME NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_enq_receipt` (`receipt_id`),
  KEY `idx_enq_sync` (`sheet_sync_status`),
  KEY `idx_enq_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `sync_audit_logs` (
  `id` VARCHAR(64) NOT NULL,
  `action` VARCHAR(80) NOT NULL,
  `target_type` ENUM('career', 'contact', 'workspace', 'settings') NOT NULL,
  `receipt_id` VARCHAR(80) NOT NULL DEFAULT '',
  `status` ENUM('ok', 'warning', 'error') NOT NULL,
  `detail` VARCHAR(500) NOT NULL,
  `actor_email` VARCHAR(150) NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_log_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `career_roles` (
  `id` VARCHAR(64) NOT NULL,
  `name` VARCHAR(100) NOT NULL,
  `description` VARCHAR(255) NOT NULL DEFAULT '',
  `active` TINYINT(1) NOT NULL DEFAULT 1,
  `sort_order` INT NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_role_name` (`name`),
  KEY `idx_role_sort` (`active`, `sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
