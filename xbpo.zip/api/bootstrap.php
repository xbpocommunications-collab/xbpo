<?php
/**
 * XBPO Communications - Shared PHP Bootstrap, Security Validators, MariaDB PDO & Session Helpers
 * Compatible with PHP 7.4+ and PHP 8.x on Plesk Windows (IIS) & Linux (Apache).
 */

@ini_set('display_errors', '0');
error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE);

define('XBPO_MASTER_EMAIL', 'xbpocommunications@gmail.com');
define('XBPO_DEFAULT_MASTER_PASSWORD', 'Xbpo@2026!ChangeMe');
define('XBPO_COOKIE_NAME', 'xbpo_session');
define('XBPO_MAX_CV_BYTES', 3 * 1024 * 1024);

define('XBPO_DEFAULT_SETTINGS', [
    'instagramUrl' => 'https://www.instagram.com/xbpocommunications/',
    'facebookUrl' => 'https://www.facebook.com/profile.php?id=61591924862912',
    'googleUrl' => 'https://share.google/2uXwuCsCKBf2bV1MM',
    'contactEmail' => 'official@xbpoandcommunnications.com',
    'contactPhone' => '+923285382722',
    'appsScriptUrl' => '',
    'spreadsheetId' => '',
    'driveFolderId' => '',
    'spreadsheetUrl' => '',
    'driveFolderUrl' => '',
]);

define('XBPO_DEFAULT_ROLES', [
    [
        'id' => 'role_fronter',
        'name' => 'Fronter',
        'description' => 'Open the conversation, qualify the prospect and hand a valid call to the closer.',
        'active' => 1,
        'sort_order' => 1,
    ],
    [
        'id' => 'role_closer',
        'name' => 'Closer',
        'description' => 'Take the qualified handoff, control the sales-stage conversation and progress the call.',
        'active' => 1,
        'sort_order' => 2,
    ],
    [
        'id' => 'role_verifier',
        'name' => 'Verifier',
        'description' => 'Confirm the required details and complete the defined verification checkpoints accurately.',
        'active' => 1,
        'sort_order' => 3,
    ],
    [
        'id' => 'role_team_lead',
        'name' => 'Team Lead',
        'description' => 'Supervise outbound floor performance, coaching, and shift quality standards.',
        'active' => 1,
        'sort_order' => 4,
    ],
]);

define('XBPO_ALLOWED_SERVICES', [
    'Final Expense Campaign Support',
    'US Outbound Calling',
    'Lead Generation & Qualification',
    'Appointments & Live Transfers',
    'Quality Assurance & Verification',
    'Campaign Operations & Team Support',
    'Other',
]);

define('XBPO_ALLOWED_EXPERIENCE', [
    'Fresher / No experience',
    'Less than 1 year',
    '1–2 years',
    '1-2 years',
    '3–5 years',
    '3-5 years',
    '5+ years',
]);

function xbpo_load_env(): array
{
    static $loaded = null;
    if ($loaded !== null) {
        return $loaded;
    }
    $env = [];
    $candidates = [
        __DIR__ . '/../.env',
        __DIR__ . '/../../.env',
    ];
    foreach ($candidates as $path) {
        if (!is_file($path) || !is_readable($path)) {
            continue;
        }
        $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if (!$lines) {
            continue;
        }
        foreach ($lines as $rawLine) {
            $line = trim($rawLine);
            if ($line === '' || $line[0] === '#') {
                continue;
            }
            $eq = strpos($line, '=');
            if ($eq === false) {
                continue;
            }
            $key = trim(substr($line, 0, $eq));
            if (!preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $key)) {
                continue;
            }
            $val = trim(substr($line, $eq + 1));
            $len = strlen($val);
            if ($len >= 2 && (($val[0] === '"' && $val[$len - 1] === '"') || ($val[0] === "'" && $val[$len - 1] === "'"))) {
                $val = substr($val, 1, -1);
            }
            if (!array_key_exists($key, $env)) {
                $env[$key] = $val;
            }
        }
        break;
    }
    $loaded = $env;
    return $env;
}

function xbpo_env(string $key, string $default = ''): string
{
    $env = xbpo_load_env();
    if (array_key_exists($key, $env)) {
        return (string)$env[$key];
    }
    $sys = getenv($key);
    if ($sys !== false && $sys !== '') {
        return (string)$sys;
    }
    return $default;
}

function xbpo_temp_dir(string $sub): string
{
    $base = rtrim(sys_get_temp_dir(), "\\/");
    $dir = $base . DIRECTORY_SEPARATOR . 'xbpo_' . substr(md5(__DIR__), 0, 10) . '_' . $sub;
    if (!is_dir($dir)) {
        @mkdir($dir, 0750, true);
    }
    if (!is_dir($dir) || !is_writable($dir)) {
        $fallback = __DIR__ . '/../App_Data/xbpo_' . $sub;
        if (!is_dir($fallback)) {
            @mkdir($fallback, 0750, true);
        }
        return $fallback;
    }
    return $dir;
}

function xbpo_session_secret(): string
{
    $fromEnv = xbpo_env('SESSION_SECRET', '');
    if (strlen($fromEnv) >= 16) {
        return $fromEnv;
    }
    $secretFile = xbpo_temp_dir('sys') . DIRECTORY_SEPARATOR . 'session_secret.key';
    if (is_file($secretFile)) {
        $stored = trim((string)@file_get_contents($secretFile));
        if (strlen($stored) >= 32) {
            return $stored;
        }
    }
    $generated = bin2hex(random_bytes(32));
    @file_put_contents($secretFile, $generated);
    return $generated;
}

function xbpo_pdo(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }
    $host = xbpo_env('MYSQL_HOST', '');
    $port = xbpo_env('MYSQL_PORT', '3306');
    $db = xbpo_env('MYSQL_DATABASE', '');
    $user = xbpo_env('MYSQL_USER', '');
    $pass = xbpo_env('MYSQL_PASSWORD', '');

    if ($host === '' || $db === '' || $user === '') {
        throw new RuntimeException('MariaDB .env credentials are not configured yet (MYSQL_HOST, MYSQL_DATABASE, MYSQL_USER).');
    }

    $dsn = sprintf('mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4', $host, $port ?: '3306', $db);
    $pdo = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    xbpo_seed_defaults($pdo);
    return $pdo;
}

function xbpo_seed_defaults(PDO $pdo): void
{
    $stmt = $pdo->prepare('SELECT id FROM admin_users WHERE email = ? LIMIT 1');
    $stmt->execute([XBPO_MASTER_EMAIL]);
    if (!$stmt->fetch()) {
        $ins = $pdo->prepare(
            'INSERT IGNORE INTO admin_users (id, email, name, role, password_hash, active) VALUES (?, ?, ?, ?, ?, ?)'
        );
        $ins->execute([
            'master_xbpo',
            XBPO_MASTER_EMAIL,
            'Master Administrator',
            'master',
            password_hash(XBPO_DEFAULT_MASTER_PASSWORD, PASSWORD_BCRYPT),
            1,
        ]);
    }

    $stmt2 = $pdo->prepare('SELECT setting_key FROM site_settings WHERE setting_key = ? LIMIT 1');
    $stmt2->execute(['public']);
    if (!$stmt2->fetch()) {
        $ins2 = $pdo->prepare(
            'INSERT IGNORE INTO site_settings (setting_key, instagram_url, facebook_url, google_url, contact_email, contact_phone, apps_script_url, spreadsheet_id, drive_folder_id, updated_by)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
        );
        $ins2->execute([
            'public',
            XBPO_DEFAULT_SETTINGS['instagramUrl'],
            XBPO_DEFAULT_SETTINGS['facebookUrl'],
            XBPO_DEFAULT_SETTINGS['googleUrl'],
            XBPO_DEFAULT_SETTINGS['contactEmail'],
            XBPO_DEFAULT_SETTINGS['contactPhone'],
            '',
            '',
            '',
            'system',
        ]);
    }

    $cnt = (int)$pdo->query('SELECT COUNT(*) FROM career_roles')->fetchColumn();
    if ($cnt === 0) {
        $insRole = $pdo->prepare(
            'INSERT IGNORE INTO career_roles (id, name, description, active, sort_order) VALUES (?, ?, ?, ?, ?)'
        );
        foreach (XBPO_DEFAULT_ROLES as $r) {
            $insRole->execute([$r['id'], $r['name'], $r['description'], $r['active'], $r['sort_order']]);
        }
    }
}

function xbpo_iso_date(?string $dt): string
{
    if (!$dt) {
        return '';
    }
    $ts = strtotime($dt);
    return $ts ? gmdate('Y-m-d\TH:i:s\Z', $ts) : $dt;
}

function xbpo_sanitize_text($value, int $maxLen = 250, bool $allowNewlines = false): string
{
    $str = (string)($value ?? '');
    $str = str_replace("\0", '', $str);
    $str = preg_replace('/[\x01-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $str) ?? $str;
    if (!$allowNewlines) {
        $str = preg_replace('/[\r\n]+/', ' ', $str) ?? $str;
    }
    $str = trim($str);
    if (function_exists('mb_substr')) {
        return mb_substr($str, 0, $maxLen, 'UTF-8');
    }
    return substr($str, 0, $maxLen);
}

function xbpo_assert_no_sqli(string $value, string $fieldName): void
{
    $pattern = '/(\b(union\s+select|union\s+all|drop\s+table|drop\s+database|truncate\s+table|alter\s+table|delete\s+from|insert\s+into|update\s+\w+\s+set|exec\s*\(|execute\s*\(|xp_cmdshell|information_schema|sleep\s*\(|benchmark\s*\(|waitfor\s+delay)\b|--\s|\/\*|\*\/)/i';
    if (preg_match($pattern, $value)) {
        throw new InvalidArgumentException("Rejected unsafe input pattern in {$fieldName}.");
    }
}

function xbpo_is_valid_email(string $email): bool
{
    $s = trim($email);
    return strlen($s) >= 5
        && strlen($s) <= 150
        && (bool)preg_match('/^[^\s@<>()\[\]\\\\,;:\'"]+@[^\s@<>()\[\]\\\\,;:\'"]+\.[^\s@<>()\[\]\\\\,;:\'"]{2,}$/', $s);
}

function xbpo_is_valid_phone(string $phone): bool
{
    $s = trim($phone);
    return (bool)preg_match('/^[+0-9() .-]{10,32}$/', $s);
}

function xbpo_is_valid_http_url(string $url, bool $allowEmpty = false): bool
{
    $s = trim($url);
    if ($s === '') {
        return $allowEmpty;
    }
    if (strlen($s) > 300) {
        return false;
    }
    $parts = parse_url($s);
    if (!is_array($parts) || empty($parts['scheme']) || empty($parts['host'])) {
        return false;
    }
    $scheme = strtolower($parts['scheme']);
    return $scheme === 'https' || $scheme === 'http';
}

function xbpo_is_valid_receipt_id(string $id): bool
{
    return (bool)preg_match('/^[A-Za-z0-9_-]{16,80}$/', $id);
}

function xbpo_formula_safe_cell($value): string
{
    $str = (string)($value ?? '');
    return preg_match('/^[\s]*[=+\-@\t\r]/', $str) ? "'" . $str : $str;
}

function xbpo_csv_cell($value): string
{
    $safe = xbpo_formula_safe_cell($value);
    return '"' . str_replace('"', '""', $safe) . '"';
}

function xbpo_validate_cv_upload(string $resumeName, string $resumeBase64): array
{
    $rawName = xbpo_sanitize_text($resumeName, 200);
    if ($rawName === '' || strpos($rawName, '..') !== false || strpos($rawName, '/') !== false || strpos($rawName, '\\') !== false) {
        throw new InvalidArgumentException('Invalid CV filename.');
    }
    $parts = explode('.', $rawName);
    $ext = strtolower(end($parts) ?: '');
    $mimeByExt = [
        'pdf' => 'application/pdf',
        'doc' => 'application/msword',
        'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    ];
    if (!isset($mimeByExt[$ext])) {
        throw new InvalidArgumentException('Only PDF, DOC, or DOCX CVs are allowed.');
    }
    $cleanB64 = preg_replace('/\s+/', '', $resumeBase64) ?? '';
    if ($cleanB64 === '' || strlen($cleanB64) > 4500000 || !preg_match('/^[A-Za-z0-9+\/=]+$/', $cleanB64)) {
        throw new InvalidArgumentException('Invalid CV file encoding.');
    }
    $bin = base64_decode($cleanB64, true);
    if ($bin === false || strlen($bin) < 8 || strlen($bin) > XBPO_MAX_CV_BYTES) {
        throw new InvalidArgumentException('CV file must be between 8 bytes and 3 MB.');
    }

    $b0 = ord($bin[0]);
    $b1 = ord($bin[1]);
    $b2 = ord($bin[2]);
    $b3 = ord($bin[3]);
    $b4 = ord($bin[4]);

    $isPdf = ($b0 === 0x25 && $b1 === 0x50 && $b2 === 0x44 && $b3 === 0x46 && $b4 === 0x2D); // %PDF-
    $isZip = ($b0 === 0x50 && $b1 === 0x4B && ($b2 === 0x03 || $b2 === 0x05 || $b2 === 0x07)); // PK..
    $isDoc = ($b0 === 0xD0 && $b1 === 0xCF && $b2 === 0x11 && $b3 === 0xE0); // OLE2

    if (($ext === 'pdf' && !$isPdf) || ($ext === 'docx' && !$isZip) || ($ext === 'doc' && !$isDoc)) {
        throw new InvalidArgumentException('CV file signature does not match its extension.');
    }

    $safeFileName = substr(preg_replace('/[^a-zA-Z0-9._-]/', '_', $rawName) ?? 'cv.' . $ext, 0, 100);
    return [
        'safeFileName' => $safeFileName,
        'mimeType' => $mimeByExt[$ext],
        'sizeBytes' => strlen($bin),
        'base64' => $cleanB64,
    ];
}

function xbpo_set_transient_cv(string $receiptId, array $cv): void
{
    $dir = xbpo_temp_dir('cv');
    // Purge expired temp CVs older than 24h
    $now = time();
    foreach (glob($dir . DIRECTORY_SEPARATOR . '*.json') ?: [] as $file) {
        if ($now - (@filemtime($file) ?: $now) > 86400) {
            @unlink($file);
        }
    }
    $payload = [
        'safeFileName' => $cv['safeFileName'],
        'mimeType' => $cv['mimeType'],
        'sizeBytes' => (int)$cv['sizeBytes'],
        'base64' => $cv['base64'],
        'expiresAt' => ($now + 86400) * 1000,
    ];
    @file_put_contents($dir . DIRECTORY_SEPARATOR . preg_replace('/[^A-Za-z0-9_-]/', '', $receiptId) . '.json', json_encode($payload));
}

function xbpo_get_transient_cv(string $receiptId): ?array
{
    $file = xbpo_temp_dir('cv') . DIRECTORY_SEPARATOR . preg_replace('/[^A-Za-z0-9_-]/', '', $receiptId) . '.json';
    if (!is_file($file)) {
        return null;
    }
    $raw = @file_get_contents($file);
    if (!$raw) {
        return null;
    }
    $data = json_decode($raw, true);
    if (!is_array($data) || (($data['expiresAt'] ?? 0) < (time() * 1000))) {
        @unlink($file);
        return null;
    }
    return $data;
}

function xbpo_clear_transient_cv(string $receiptId): void
{
    $file = xbpo_temp_dir('cv') . DIRECTORY_SEPARATOR . preg_replace('/[^A-Za-z0-9_-]/', '', $receiptId) . '.json';
    if (is_file($file)) {
        @unlink($file);
    }
}

function xbpo_verify_password(string $password, string $storedHash): bool
{
    if (strpos($storedHash, '$2') === 0 || strpos($storedHash, '$argon2') === 0) {
        return password_verify($password, $storedHash);
    }
    return false;
}

function xbpo_b64url_encode(string $data): string
{
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

function xbpo_b64url_decode(string $str): ?string
{
    $padded = strtr($str, '-_', '+/') . str_repeat('=', (4 - (strlen($str) % 4)) % 4);
    $out = base64_decode($padded, true);
    return $out === false ? null : $out;
}

function xbpo_sign_token(array $payload, int $ttlSeconds = 43200): string
{
    $payload['exp'] = time() + $ttlSeconds;
    $encoded = xbpo_b64url_encode((string)json_encode($payload));
    $sig = xbpo_b64url_encode(hash_hmac('sha256', $encoded, xbpo_session_secret(), true));
    return $encoded . '.' . $sig;
}

function xbpo_verify_token(?string $token): ?array
{
    if (!$token || strpos($token, '.') === false) {
        return null;
    }
    $parts = explode('.', $token, 2);
    if (count($parts) !== 2) {
        return null;
    }
    [$encoded, $sig] = $parts;
    $expected = xbpo_b64url_encode(hash_hmac('sha256', $encoded, xbpo_session_secret(), true));
    if (!hash_equals($expected, $sig)) {
        return null;
    }
    $json = xbpo_b64url_decode($encoded);
    if ($json === null) {
        return null;
    }
    $data = json_decode($json, true);
    if (!is_array($data) || empty($data['exp']) || (int)$data['exp'] < time()) {
        return null;
    }
    return $data;
}

function xbpo_is_https(): bool
{
    if (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off') {
        return true;
    }
    if (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower(trim(explode(',', (string)$_SERVER['HTTP_X_FORWARDED_PROTO'])[0])) === 'https') {
        return true;
    }
    return ((int)($_SERVER['SERVER_PORT'] ?? 80)) === 443;
}

function xbpo_set_session_cookie(array $user): void
{
    $token = xbpo_sign_token([
        'id' => $user['id'],
        'email' => $user['email'],
        'name' => $user['name'],
        'role' => $user['role'],
    ], 43200);

    $https = xbpo_is_https();
    setcookie(XBPO_COOKIE_NAME, $token, [
        'expires' => time() + 43200,
        'path' => '/',
        'httponly' => true,
        'samesite' => $https ? 'None' : 'Lax',
        'secure' => $https,
    ]);
}

function xbpo_clear_session_cookie(): void
{
    $https = xbpo_is_https();
    setcookie(XBPO_COOKIE_NAME, '', [
        'expires' => time() - 3600,
        'path' => '/',
        'httponly' => true,
        'samesite' => $https ? 'None' : 'Lax',
        'secure' => $https,
    ]);
}

function xbpo_current_admin(): ?array
{
    $token = $_COOKIE[XBPO_COOKIE_NAME] ?? null;
    return xbpo_verify_token($token);
}

function xbpo_check_rate_limit(string $scope, int $windowSec, int $maxHits): void
{
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $ip = trim(explode(',', (string)$ip)[0]);
    $file = xbpo_temp_dir('rl') . DIRECTORY_SEPARATOR . sha1($scope . '|' . $ip) . '.json';
    $now = time();
    $hits = [];
    if (is_file($file)) {
        $decoded = json_decode((string)@file_get_contents($file), true);
        if (is_array($decoded)) {
            foreach ($decoded as $ts) {
                if (($now - (int)$ts) < $windowSec) {
                    $hits[] = (int)$ts;
                }
            }
        }
    }
    if (count($hits) >= $maxHits) {
        xbpo_json(429, ['error' => 'Too many requests. Please try again shortly.']);
    }
    $hits[] = $now;
    @file_put_contents($file, json_encode($hits));
}

function xbpo_json(int $status, array $data): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_SLASHES);
    exit;
}

function xbpo_security_headers(): void
{
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
}
